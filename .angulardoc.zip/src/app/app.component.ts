import { UserManagementService } from "./Services/user-management.service";
import { Component, OnDestroy, OnInit } from "@angular/core";
import { CustomControl } from "./Common/control";
import { FormGroup } from "@angular/forms";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {

  constructor() {}
  ngOnInit() {

  }



}

export class DropdownItem{
  public value?:string;
  public name?:string;

}
